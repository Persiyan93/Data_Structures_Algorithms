﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Tree
{
    class Class1
    {
        private static void  Main()
        {

        }
    }
}
